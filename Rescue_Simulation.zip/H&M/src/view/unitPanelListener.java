package view;

import java.awt.event.MouseListener;

public interface unitPanelListener extends MouseListener{

}
