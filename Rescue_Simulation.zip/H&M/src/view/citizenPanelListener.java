package view;

import java.awt.event.MouseListener;

public interface citizenPanelListener extends MouseListener{

}
