package view;
import javax.swing.JButton;
public class nextCycleButton extends JButton{
	public nextCycleButton() {
		super("NEXT CYCLE");
		setActionCommand("next");
	}

}
