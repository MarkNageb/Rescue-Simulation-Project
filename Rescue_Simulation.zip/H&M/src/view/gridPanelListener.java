package view;

import java.awt.event.MouseListener;

public interface gridPanelListener extends MouseListener {

}
