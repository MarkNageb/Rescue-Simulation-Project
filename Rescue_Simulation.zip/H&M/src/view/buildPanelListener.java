package view;

import java.awt.event.MouseListener;

public interface buildPanelListener extends MouseListener{

}
