package model.infrastructure;

public enum HospitalType {
	PUBLIC, PRIVATE , INTERNATIONAL;
}
